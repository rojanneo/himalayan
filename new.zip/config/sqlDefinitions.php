<?php
if (!defined('MYSQL_Server')) {
	define('MYSQL_Server', 'localhost');
}

if (!defined('MYSQL_User')) {
	define('MYSQL_User', 'himalaya_dog');
}

if (!defined('MYSQL_Password')) {
	define('MYSQL_Password', 'hello123');
}

if (!defined('DATABASE')) {
	define('DATABASE', 'himalaya_dog');
}
?>