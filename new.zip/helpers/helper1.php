<?php

if(!function_exists('helper_test'))
{
	function helper_test()
	{
		echo 'test successfull';
	}
}