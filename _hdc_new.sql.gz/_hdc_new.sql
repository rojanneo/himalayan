-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2014 at 11:15 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `_hdc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_session`
--

DROP TABLE IF EXISTS `admin_session`;
CREATE TABLE IF NOT EXISTS `admin_session` (
  `session_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_id` text NOT NULL,
  `admin_type` int(11) NOT NULL,
  `session_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`),
  KEY `admin_type` (`admin_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

--
-- Dumping data for table `admin_session`
--

INSERT INTO `admin_session` (`session_id`, `user_id`, `token_id`, `admin_type`, `session_time`) VALUES
(44, 3942, 'rojan_neo@hotmail.com', 4, '2014-08-27 11:59:37'),
(45, 3942, 'rojan_neo@hotmail.com', 4, '2014-08-27 12:01:24'),
(46, 3942, 'rojan_neo@hotmail.com', 4, '2014-08-27 12:33:13'),
(47, 3942, 'rojan_neo@hotmail.com', 4, '2014-08-30 14:56:19'),
(48, 3942, 'rojan_neo@hotmail.com', 4, '2014-08-31 16:24:39'),
(49, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-01 09:38:07'),
(50, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-01 09:38:46'),
(51, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-01 11:12:08'),
(52, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-02 10:36:29'),
(53, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-02 13:33:37'),
(54, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-02 16:50:31'),
(55, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-02 17:19:57'),
(56, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-03 09:45:14'),
(57, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-03 10:58:43'),
(58, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-03 11:55:37'),
(59, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-03 15:08:19'),
(60, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-03 16:43:09'),
(61, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-04 09:58:21'),
(62, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-04 10:41:15'),
(63, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-05 09:48:11'),
(64, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-05 10:03:14'),
(65, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-05 10:24:54'),
(66, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-05 10:35:30'),
(67, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-05 12:25:35'),
(68, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-05 12:44:26'),
(69, 3942, 'rojan_neo@hotmail.com', 4, '2014-09-05 14:57:54');

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

DROP TABLE IF EXISTS `attributes`;
CREATE TABLE IF NOT EXISTS `attributes` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `acode` varchar(255) NOT NULL,
  `aname` varchar(255) NOT NULL,
  `atype` enum('int','text','select','varchar') NOT NULL,
  `used_for_variation` int(11) NOT NULL DEFAULT '0',
  `is_required` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `attributes`
--

INSERT INTO `attributes` (`aid`, `acode`, `aname`, `atype`, `used_for_variation`, `is_required`) VALUES
(9, 'dog_size', 'Dog Size', 'select', 0, 1),
(10, 'ingredients', 'Ingedients', 'varchar', 0, 0),
(11, 'guarantee', 'Guaranteed Analysis', 'varchar', 0, 0),
(12, 'no_of_pieces', 'Number of Pieces', 'int', 0, 0),
(15, 'weight', 'Weight', 'int', 0, 0),
(16, 'weight_unit', 'Weight Unit', 'select', 0, 0),
(17, 'weight_type', 'Weight Type', 'select', 0, 0),
(18, 'min_pieces', 'Minimum Pieces', 'int', 0, 1),
(19, 'max_pieces', 'Maximum Pieces', 'int', 0, 1),
(20, 'min_cal', 'Minimum Calorie', 'int', 0, 1),
(21, 'max_cal', 'Maximum Calorie', 'int', 0, 1),
(22, 'calories', 'Calories', 'int', 0, 0),
(23, 'calorie_type', 'Calories Unit', 'select', 0, 0),
(24, 'pieces_per_box', 'Pieces Per Box', 'int', 0, 0),
(25, 'length', 'Length', 'int', 0, 0),
(26, 'length_uni', 'Length Unit', 'select', 0, 0),
(27, 'test', 'test', 'select', 0, 0),
(28, 'adf', 'sdf', 'select', 0, 0),
(29, 'box_size_crunch', 'Box Size (Yaky Crunch)', 'select', 1, 0),
(32, 'price', 'Price', 'text', 0, 0),
(33, 'box_size_yam', 'Box Size (Yaky Yam)', 'select', 1, 0),
(34, 'caption_text', 'Caption', 'text', 0, 0),
(35, 'display_name', 'Display Name', 'varchar', 0, 1),
(36, 'short_description', 'Short Description', 'text', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `attributeset`
--

DROP TABLE IF EXISTS `attributeset`;
CREATE TABLE IF NOT EXISTS `attributeset` (
  `asid` int(11) NOT NULL AUTO_INCREMENT,
  `ascode` varchar(255) NOT NULL,
  `asname` varchar(255) NOT NULL,
  PRIMARY KEY (`asid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `attributeset`
--

INSERT INTO `attributeset` (`asid`, `ascode`, `asname`) VALUES
(10, 'chews', 'HDC Chews'),
(11, 'seasoning', 'HDC Seasonings'),
(12, 'yaky_crunch', 'Yaky Crunch'),
(13, 'yaky_nugget', 'Yaky Nugget'),
(14, 'yaky_puff', 'Yaky Puff'),
(15, 'yaky_stick', 'Yaky Sticks'),
(16, 'yaky_yam', 'Yaky Yam');

-- --------------------------------------------------------

--
-- Table structure for table `attribute_values`
--

DROP TABLE IF EXISTS `attribute_values`;
CREATE TABLE IF NOT EXISTS `attribute_values` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `values_aid` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`vid`),
  KEY `values_aid` (`values_aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=73 ;

--
-- Dumping data for table `attribute_values`
--

INSERT INTO `attribute_values` (`vid`, `values_aid`, `value`) VALUES
(43, 9, '15 lbs'),
(44, 9, '35 lbs'),
(45, 9, '55 lbs'),
(46, 9, '65 lbs'),
(47, 9, '70 lbs'),
(48, 9, '50 lbs'),
(52, 16, 'lbs'),
(53, 16, 'kg'),
(54, 17, 'per box'),
(55, 17, 'per bottle'),
(58, 26, 'centimeters'),
(59, 26, 'Inches'),
(60, 23, 'per box'),
(61, 23, 'per bottle'),
(62, 23, 'per treat'),
(63, 27, 'test'),
(64, 28, 'sadf'),
(65, 28, 'asdf'),
(66, 29, '1.5 oz'),
(67, 29, '3 oz'),
(68, 23, 'None'),
(69, 9, '25 lbs'),
(70, 9, 'All'),
(71, 33, '4 oz'),
(72, 33, '14 oz');

-- --------------------------------------------------------

--
-- Table structure for table `a_as`
--

DROP TABLE IF EXISTS `a_as`;
CREATE TABLE IF NOT EXISTS `a_as` (
  `aasid` int(11) NOT NULL AUTO_INCREMENT,
  `aas_aid` int(11) NOT NULL,
  `aas_asid` int(11) NOT NULL,
  PRIMARY KEY (`aasid`),
  KEY `aas_aid` (`aas_aid`,`aas_asid`),
  KEY `aas_asid` (`aas_asid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=639 ;

--
-- Dumping data for table `a_as`
--

INSERT INTO `a_as` (`aasid`, `aas_aid`, `aas_asid`) VALUES
(614, 9, 10),
(626, 9, 11),
(598, 9, 12),
(586, 9, 13),
(574, 9, 14),
(561, 9, 15),
(545, 9, 16),
(615, 10, 10),
(627, 10, 11),
(599, 10, 12),
(587, 10, 13),
(575, 10, 14),
(562, 10, 15),
(546, 10, 16),
(616, 11, 10),
(628, 11, 11),
(600, 11, 12),
(588, 11, 13),
(576, 11, 14),
(563, 11, 15),
(547, 11, 16),
(629, 15, 11),
(601, 15, 12),
(548, 15, 16),
(630, 16, 11),
(602, 16, 12),
(549, 16, 16),
(631, 17, 11),
(603, 17, 12),
(550, 17, 16),
(617, 18, 10),
(604, 18, 12),
(589, 18, 13),
(577, 18, 14),
(551, 18, 16),
(618, 19, 10),
(605, 19, 12),
(590, 19, 13),
(578, 19, 14),
(552, 19, 16),
(619, 20, 10),
(632, 20, 11),
(606, 20, 12),
(591, 20, 13),
(579, 20, 14),
(564, 20, 15),
(553, 20, 16),
(620, 21, 10),
(633, 21, 11),
(607, 21, 12),
(592, 21, 13),
(580, 21, 14),
(565, 21, 15),
(554, 21, 16),
(621, 23, 10),
(634, 23, 11),
(608, 23, 12),
(593, 23, 13),
(581, 23, 14),
(566, 23, 15),
(555, 23, 16),
(567, 24, 15),
(568, 25, 15),
(569, 26, 15),
(609, 29, 12),
(622, 32, 10),
(635, 32, 11),
(610, 32, 12),
(594, 32, 13),
(582, 32, 14),
(570, 32, 15),
(556, 32, 16),
(557, 33, 16),
(623, 34, 10),
(636, 34, 11),
(611, 34, 12),
(595, 34, 13),
(583, 34, 14),
(571, 34, 15),
(558, 34, 16),
(624, 35, 10),
(637, 35, 11),
(612, 35, 12),
(596, 35, 13),
(584, 35, 14),
(572, 35, 15),
(559, 35, 16),
(625, 36, 10),
(638, 36, 11),
(613, 36, 12),
(597, 36, 13),
(585, 36, 14),
(573, 36, 15),
(560, 36, 16);

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
CREATE TABLE IF NOT EXISTS `blog` (
  `blog_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_title` text NOT NULL,
  `blog_content` longtext NOT NULL,
  `blog_status` varchar(20) NOT NULL,
  `blog_guid` varchar(255) NOT NULL,
  `blog-published_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `blog_name` varchar(200) NOT NULL,
  `blog_feature_image` varchar(200) DEFAULT NULL,
  `blog_revised_date` datetime NOT NULL,
  PRIMARY KEY (`blog_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blog_id`, `blog_title`, `blog_content`, `blog_status`, `blog_guid`, `blog-published_date`, `blog_name`, `blog_feature_image`, `blog_revised_date`) VALUES
(1, 'alinatest', '<p>bhari&nbsp;<img src="../../../assets/uploads/cms/10547438_872609119446337_4240389877025763258_n.jpg" alt="10547438_872609119446337_4240389877025763258_n" /></p>', 'publish', 'http://alina/himalayan/alina', '2014-08-30 13:04:23', 'alina', 'cms/croppedImg_10298.jpeg', '2014-08-22 13:04:23'),
(11, 'Test Editor', '<p>this is test sadfasdf<img title="Laughing" src="../../../assets/js/tiny_mce/plugins/emotions/img/smiley-laughing.gif" alt="Laughing" border="0" /><img title="Kiss" src="../../../assets/js/tiny_mce/plugins/emotions/img/smiley-kiss.gif" alt="Kiss" border="0" /></p>\n<p>&nbsp;<img title="Cool" src="../../../assets/js/tiny_mce/plugins/emotions/img/smiley-cool.gif" alt="Cool" border="0" /><img title="Frown" src="../../../assets/js/tiny_mce/plugins/emotions/img/smiley-frown.gif" alt="Frown" border="0" /><img title="Yell" src="../../../assets/js/tiny_mce/plugins/emotions/img/smiley-yell.gif" alt="Yell" border="0" /><img title="Undecided" src="../../../assets/js/tiny_mce/plugins/emotions/img/smiley-undecided.gif" alt="Undecided" border="0" /></p>\n<p><strong>asdfasd</strong></p>', 'publish', 'http://alina/himalayan/Test_Editor', '2014-08-20 15:35:17', 'Test_Editor', NULL, '0000-00-00 00:00:00'),
(14, 'test', '<p>asdfa<img src="http://alina/himalayan/assets/uploads/photogallery/cropped/elle.jpg" alt="" /></p>', 'draft', 'http://alina/himalayan/test', '2014-08-21 11:50:04', 'test', NULL, '0000-00-00 00:00:00'),
(16, 'this is a test', '<p>dfadsfasdfadsfa<img src="cms/Jellyfish.jpg" alt="" /></p>', 'publish', 'http://alina/himalayan/this_is_a_test', '2014-08-21 16:24:49', 'this_is_a_test', NULL, '0000-00-00 00:00:00'),
(17, 'sadfads', '<p>sadf<img src="C:xampphtdocshimalayanassetsuploadscmsTulips1.jpeg" alt="" /></p>', 'publish', 'http://alina/himalayan/sadfads', '2014-08-21 16:40:07', 'sadfads', NULL, '0000-00-00 00:00:00'),
(18, 'pengiuin plse ', '<p>dsmfnsadf<img src="../../../assets/uploads/photogallery/cropped/Penguins.jpg" alt="" />fasdf<img src="../../../assets/uploads/photogallery/cropped/Koala.jpg" alt="" /></p>', 'publish', 'http://alina/himalayan/pengiuin_plse_', '2014-08-01 09:46:32', 'pengiuin_plse_', NULL, '2014-08-22 09:46:32'),
(26, 'test', '<p>sadfdsa</p>', 'publish', 'http://alina/himalayan/test', '2014-08-22 12:52:23', 'test', NULL, '2014-08-22 12:52:23'),
(27, 'asdfa', '<p>asdfads</p>', 'publish', 'http://alina/himalayan/asdfa', '2014-08-22 16:39:52', 'asdfa', 'cms/croppedImg_17253.jpeg', '0000-00-00 00:00:00'),
(28, 'fadf', '<p>afdasdf</p>', 'publish', 'http://alina/himalayan/fadf', '2014-08-22 16:43:56', 'fadf', 'cms/croppedImg_21035.jpeg', '0000-00-00 00:00:00'),
(32, 'alin', '<p>adsfasdfadsfdsafdsafsdafa</p>', 'publish', 'http://alina/himalayan/alin', '2014-08-24 11:33:56', 'alin', '', '0000-00-00 00:00:00'),
(33, 'alina', '<p>lsdajfkladsjflsakdfnladsf</p>', 'publish', 'http://alina/himalayan/alina', '2014-08-24 11:35:19', 'alina53f97d1b9d4d4', '', '0000-00-00 00:00:00'),
(34, 'alina', '<p>aklsdjfalskdhf</p>', 'publish', 'http://alina/himalayan/alina', '2014-08-24 11:35:47', 'alina53f97d376c9e2', '', '0000-00-00 00:00:00'),
(35, 'alina', '<p>jalskjfladsjfsadfadsf</p>', 'publish', 'http://alina/himalayan/alina', '2014-08-24 13:33:10', 'alina53f998ba3cb93', '', '0000-00-00 00:00:00'),
(36, 'dog', '<p>asdfads</p>', 'publish', 'http://alina/himalayan/dog', '2014-08-24 06:08:38', 'dog53f998cff1ef7', 'cms/croppedImg_30486.jpeg', '2014-09-01 06:08:38'),
(38, 'confuguration', '<p>asdf &nbsp;{{widgets identifier=test_widget}}</p>', 'publish', 'http://alina/himalayan/doga', '2014-08-24 06:08:22', 'doga53f999133eb2e', 'cms/croppedImg_21553.jpeg', '2014-09-01 06:08:22');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_slug` varchar(200) DEFAULT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_description` longtext NOT NULL,
  `category_image` text,
  `parent_id` int(11) NOT NULL,
  `is_root` int(1) NOT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `cat_slug` (`cat_slug`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `cat_slug`, `category_name`, `category_description`, `category_image`, `parent_id`, `is_root`) VALUES
(1, 'dog-chews', 'Himalayan Dog Chews', '<h2>What is Himalayan Dog Chew?</h2>\r\n<p>Himalayan Dog Chews were born from an ancient recipe for a hard cheese snack chewed by the people of the Himalayas. In the mountains surrounding Mt. Everest at more than 15,000 feet, it is made using traditional methods with yak and/or cow milk, and all natural products with no preservatives or binding agents. <br /><br />They&rsquo;re also gluten-free! Depending on the size and eating habits of the dog, this can be a very long-lasting dog chew. Dogs must work the end of the treat for hours, softening it with their mouths before small parts of it can be slowly chewed off. When you give this treat to your dog, you know that you are providing them with hours of high-quality eating entertainment. <br /><br /></p>\r\n<h3>Key Features</h3>\r\n<ul>\r\n<li>Does not stain or stink</li>\r\n<li>Completely Digestible</li>\r\n<li>A highly nutritious treat</li>\r\n<li>Lasts 5 to 7 times longer than Bully Sticks</li>\r\n<li>Lactose-free, gluten-free &amp; grain-free</li>\r\n</ul>', '', 9, 0),
(2, 'seasoning', 'Seasoning', '<h2>What is HDC Seasoning?</h2>\r\n<p>Our Seasoning is made from the grainy powder of Himalayan Dog Chews which you can sprinkle onto any dog or cat food for pets who just cannot seem to get enough of it. <br /><br />Add a little taste of the Himalayas to all of their food! <br /><br /></p>\r\n<h3>Key Features</h3>\r\n<ul>\r\n<li>Completely digestible</li>\r\n<li>Highly nutritious cheese</li>\r\n<li>Made with 100% natural ingredients</li>\r\n<li>Lactose-free, gluten-free, &amp; grain-free</li>\r\n</ul>', '', 9, 0),
(3, 'yaky-nugget', 'Yaky Nugget', '<h2>What is Yaky Nugget?</h2>\r\n<p>Yaky Nuggets are little bite sized Himalayan Dog Chews that can be popped/puffed in a microwave and given to dogs to enjoy the cheesy flavor. These can also be boiled for ten to fifteen minutes in water to make them soft and easy to chop into smaller bits that can be served with regular dog food. <br /><br />They are also cut to size for uniformity and are carefully tested for quality before being packaged. <br /><br /></p>\r\n<h2>Key Features</h2>\r\n<ul>\r\n<li>Does not stain or stink</li>\r\n<li>Completely Digestible</li>\r\n<li>A highly nutritious treat</li>\r\n<li>Made with 100% natural ingredients</li>\r\n<li>Lactose-free, gluten-free &amp; grain-free</li>\r\n</ul>\r\n<p>&nbsp;</p>', '', 9, 0),
(4, 'yaky-puff', 'Yaky Puff', '<h2>What is Yaky Puff?</h2>\r\n<p>From the beginning, we have tried numerous ways to utilize leftover Himalayan Dog Chews. After extensive research and hundreds of attempts later, we discovered that when Yaky Nuggets are microwaved, they puff up to about five times their original size. The result is a dog treat that is not too soft and not too hard, while maintaining the same cheesy flavor dogs love! <br /><br /></p>\r\n<h2>Key Features</h2>\r\n<ul>\r\n<li>Does not stain or stink</li>\r\n<li>Completely Digestible</li>\r\n<li>A highly nutritious treat</li>\r\n<li>Made with 100% natural ingredients</li>\r\n<li>Lactose-free, gluten-free &amp; grain-free</li>\r\n<li>Give ''em the pleasure of Cheese!</li>\r\n</ul>', '', 9, 0),
(5, 'yaky-crunch', 'Yaky Crunch', '<h2>What is Yaky Crunch?</h2>\r\n<p>Yaky Crunch is made up of bite-sized Yaky Puffs which are made from the same ingredients as Himalayan Dog Chews (yak and/or cow milk, and all natural products). The result is a dog treat that is not too soft and not too hard, while maintaining the same cheesy flavor dogs love! <br /><br /></p>\r\n<h2>Key Features</h2>\r\n<ul>\r\n<li>Does not stain or stink</li>\r\n<li>Completely digestible</li>\r\n<li>Easily breakable &amp; crumble-free</li>\r\n<li>The ULTIMATE training treat for dogs</li>\r\n<li>Made with 100% natural ingredients</li>\r\n<li>Lactose-free, gluten-free, &amp; grain-free</li>\r\n<li>Now available in 1.25 ounce boxes and 3 ounce boxes!</li>\r\n</ul>', '', 9, 0),
(6, 'yaky-yams', 'Yaky Yams', '<h2>What is Yaky Yam?</h2>\r\n<p>Yaky Yam is a baked gluten-free treat made of the same ingredients as Himalayan Dog Chews (100% yak and cow milk, salt, and lime juice) mixed with sweet potato and other healthy nourishing ingredients. Now with more rewarding flavor and nutrition! <br /><br /></p>\r\n<h2>Key Features</h2>\r\n<ul>\r\n<li>Completely Digestible</li>\r\n<li>A highly nutritious treat</li>\r\n<li>Lasts 5 to 7 times longer than Bully Sticks</li>\r\n<li>Lactose-free &amp; gluten-free</li>\r\n<li>Yaky Yam Very Veggie and Yaky Yam Fruity Fruit are grain-free</li>\r\n<li>Made with 100% natural ingredients</li>\r\n<li>Available in 4 Oz and 14 Oz Boxes</li>\r\n</ul>\r\n<p>&nbsp;</p>', 'category/croppedImg_25138.png', 9, 0),
(7, 'yaky-sticks', 'Yaky Sticks', '<h2>What is Yaky Stick?</h2>\r\n<p>Yaky Stick is the combination of two of dogs&rsquo; favorite treats; Himalayan Dog Chews wrapped around a Bully Stick, which is made using patented processes without using any binding agents or glue in the USA. Bully Sticks come from all free-range grass fed cattle and provide dogs with essential proteins while Himalayan Dog Chews provide them with essential minerals. Moreover, this combination allows the Bully Stick to have little or no saliva from the dogs, hence emitting very low or no odor. While some dogs go for the cheese of Himalayan Dog Chews and some go for the Bully Sticks, we guarantee that any dog will go for Yaky Sticks, enjoying them fairly longer than a regular Bully Stick. <br /><br /></p>\r\n<h2>Key Features</h2>\r\n<ul>\r\n<li>Low odor1</li>\r\n<li>Completely Digestible</li>\r\n<li>Combination of Cheese and Beef</li>\r\n<li>Made with 100% natural ingredients</li>\r\n<li>Crumbles of cheese can be microwaved for 20 - 40 seconds (depnding on the type of microwave) to make Yaky Crunch</li>\r\n<li>Lactose-free, gluten-free &amp; grain-free</li>\r\n<li>A highly nutritious treat</li>\r\n</ul>', 'category/croppedImg_15235.png', 9, 0),
(8, 'yaky-charms', 'Yaky Charms', 'Yaky Charms', NULL, 9, 0),
(9, 'root', 'Root', '<p>Root Category</p>', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `configurations`
--

DROP TABLE IF EXISTS `configurations`;
CREATE TABLE IF NOT EXISTS `configurations` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_identifier` varchar(255) NOT NULL,
  `config_name` varchar(255) NOT NULL,
  `config_value` text NOT NULL,
  `config_group` int(11) NOT NULL,
  PRIMARY KEY (`config_id`),
  UNIQUE KEY `config_identifier` (`config_identifier`),
  KEY `config_group` (`config_group`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `configurations`
--

INSERT INTO `configurations` (`config_id`, `config_identifier`, `config_name`, `config_value`, `config_group`) VALUES
(7, 'footer_text', 'Copyright Message', 'Â© 2014 HImalayan Corporation dba Himalayan Dog Chew. All Rights reserved', 1),
(8, 'facebook_link', 'Facebook', 'http://www.facebook.com/himalayandogchew', 1),
(9, 'twitter_link', 'Twitter', 'http://www.twitter.com/himalayandog', 1),
(10, 'instagram_link', 'Instagram', 'no-link', 1),
(11, 'youtube_link', 'Youtube', 'http://www.youtube.com/himalayandogchew', 1),
(12, 'Pininterest_link', 'Pin Interest', 'http://pinterest.com/pin/create/button/?url=http%3A%2F%2Fhimalayandogchew.com&media=http%3A%2F%2Fwww.himalayandogchew.com%2Fimages%2Fhardyorama2.jpg', 1),
(13, 'linkedin_link', 'Linked In', 'no-link', 1),
(14, 'telephone', 'Telephone', '1 (855) 414 51531', 2),
(15, 'company_name', 'Company Name', 'HIMALAYAN CORPORATION, DBA HIMALAYAN DOG CHEW', 1),
(16, 'address_1', 'Address 1', '4480 Chennault Beach Road', 2),
(17, 'address_2', 'Address 2', 'Mukilteo', 2),
(18, 'state', 'State', 'WA ', 2),
(19, 'zip', 'Zip Code', '98275', 2),
(20, 'sales_email', 'Sales/Orders/Returns', 'sales@himalayandogchew.com', 3),
(21, 'vendor_email', 'Vendors ', 'vendors@himalayandogchew.com', 3),
(22, 'marketing_email', 'Marketing/Donations', 'marketing@himalayandogchew.com', 3),
(23, 'employment_email', 'Employment/HR', 'human.resource@himalayandogchew.com', 3),
(24, 'general_email', 'General Inquiries', 'info@himalayandogchew.com', 3),
(25, 'fax', 'Fax', '506.632.0177', 2),
(26, 'end-pieces-video', 'End Pieces Video', 'http://www.youtube.com/embed/O5tHjTCPzpE', 2);

-- --------------------------------------------------------

--
-- Table structure for table `config_group`
--

DROP TABLE IF EXISTS `config_group`;
CREATE TABLE IF NOT EXISTS `config_group` (
  `config_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_group_identifier` varchar(255) NOT NULL,
  `config_group_name` varchar(255) NOT NULL,
  PRIMARY KEY (`config_group_id`),
  UNIQUE KEY `config_group_identifier` (`config_group_identifier`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `config_group`
--

INSERT INTO `config_group` (`config_group_id`, `config_group_identifier`, `config_group_name`) VALUES
(1, 'general', 'General'),
(2, 'hdc', 'Himalayan Dog Chew'),
(3, 'emails', 'Emails'),
(4, 'settings', 'Settings');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

DROP TABLE IF EXISTS `contact_messages`;
CREATE TABLE IF NOT EXISTS `contact_messages` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_name` varchar(255) NOT NULL,
  `sender_email` varchar(255) NOT NULL,
  `message_nature` text NOT NULL,
  `message` longtext NOT NULL,
  `from_url` text NOT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`contact_id`, `sender_name`, `sender_email`, `message_nature`, `message`, `from_url`) VALUES
(1, 'Rojan', 'Shrestha', 'test', 'test', ''),
(2, 'Rojan Srhestha', 'rojan.shrestha@test.com', 'test nature ', 'test mesage\r\n', ''),
(3, 'Rojan', 'Shrestha', 'test', 'test', ''),
(9, 'Rojan Shrestha', 'rojan.neo@gmail.com', 'Test Nature', 'Test Message', ''),
(26, 'Rojan Shrestha', 'rojan.neo@gmail.com', 'this is a test nature', 'This is a test maessage', ''),
(30, 'Rojan Shrestha', 'rojan.neo@gmail.com', 'test', 'test', 'http://rojan/himalayan/faq/view/8'),
(31, 'dsaf', 'rojan.neo@gmail.com', 'test', 'ttest', 'http://rojan/himalayan/faq/view/1');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
CREATE TABLE IF NOT EXISTS `event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `eventName` varchar(50) NOT NULL,
  `eventslug` varchar(50) NOT NULL,
  `eventDateBegin` date NOT NULL,
  `eventDateEnd` date NOT NULL,
  `eventDesc` longtext NOT NULL,
  `eventUrl` varchar(100) NOT NULL,
  `eventstatus` varchar(20) NOT NULL,
  `event_feature_image` varchar(200) NOT NULL,
  `event_revised_date` datetime NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `eventName`, `eventslug`, `eventDateBegin`, `eventDateEnd`, `eventDesc`, `eventUrl`, `eventstatus`, `event_feature_image`, `event_revised_date`) VALUES
(1, 'alna', 'alna', '2014-08-24', '2014-08-27', '<p>sadfasdfsadfsadfadsfsadfdfsadfdsfsdafsadfadsfsadfsadfasd</p>', 'www.google.com', 'publish', '', '2014-08-27 08:41:52'),
(2, 'BLOodfasdfasd', 'BLOodfasdfasd', '2014-08-24', '0000-00-00', '<p>sfasfdasdfasdfadsfsdfadsf</p>', 'http://alina/himalayan/BLOodfasdfasd', 'publish', '', '0000-00-00 00:00:00'),
(4, 'Paws Walk', 'Paws_Walk', '2014-09-06', '0000-00-00', '<p>sfasfdadsf</p>', 'http://alina/himalayan/Paws_Walk', 'publish', '', '0000-00-00 00:00:00'),
(5, 'PFX Open House', 'PFX_Open_House', '2014-09-19', '2014-09-21', '', 'http://alina/himalayan/PFX_Open_House', 'publish', '', '0000-00-00 00:00:00'),
(6, 'Total Pet Expo', 'Total_Pet_Expo', '2014-09-19', '2014-09-21', '', 'http://alina/himalayan/Total_Pet_Expo', 'publish', '', '2014-08-27 08:42:12'),
(7, 'Animal Supply Open House', 'Animal_Supply_Open_House', '2014-10-27', '0000-00-00', '', 'http://alina/himalayan/Animal_Supply_Open_House', 'publish', '', '0000-00-00 00:00:00'),
(8, 'Atlanta Pet Expo', 'Atlanta_Pet_Expo', '2014-11-07', '0000-00-00', '', 'http://alina/himalayan/Atlanta_Pet_Expo', 'publish', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
CREATE TABLE IF NOT EXISTS `faq` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `faq_keywords` text COLLATE utf8_unicode_ci NOT NULL,
  `faq_question` longtext COLLATE utf8_unicode_ci NOT NULL,
  `faq_answer` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`faq_id`),
  FULLTEXT KEY `faq_question` (`faq_question`,`faq_answer`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`faq_id`, `faq_keywords`, `faq_question`, `faq_answer`) VALUES
(1, 'bad, stop, feeding, dog, fibrous, white, light, green, blue, spots, mold, hazardous, zipper, replacement', 'How do I know if the chew is bad?1', 'nowAlthough Himalayan Dog Chew rarely goes bad, please stop feeding the dog and call us immediately if you see fibrous white/light or green/blue spots on the chew. This is a sign of mold growth and is hazardous. We would appreciate these chews to be placed in a zipper bag and sent to us for testing. In replacement we can sadfsadsaffaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaa a send you a replacement chew right away. knowAlthough Himalayan Dog Chew rarely goes bad, please stop feeding the dog and call us immediately if you see fibrous white/light or green/blue spots on the chew. This is a sign of mold growth and is hazardous. We would appreciate these chews to be placed in a zipper bag and sent to us for testing. In replacement we can sadfsadsaffaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaa a send you a replacement chew right away. knowAlthough Himalayan Dog Chew rarely goes bad, please stop feeding the dog and call us immediately if you see fibrous white/light or nowAlthough Himalayan Dog Chew rarely goes bad, please stop feeding the dog and call us immediately if you see fibrous white/light or green/blue spots on the chew. This is a sign of mold growth and is hazardous. We would appreciate these chews to be placed in a zipper bag and sent to us for testing. In replacement we can sadfsadsaffaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaa a send you a replacement chew right away. knowAlthough Himalayan Dog Chew rarely goes bad, please stop feeding the dog and call us immediately if you see fibrous white/light or green/blue spots on the chew. This is a sign of mold growth and is hazardous. We would appreciate these chews to be placed in a zipper bag and sent to us for testing. In replacement we can sadfsadsaffaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaa a send you a replacement chew right away. knowAlthough Himalayan Dog Chew rarely goes bad, please stop feeding the dog and call us immediately if you see fibrous white/light or nowAlthough Himalayan Dog Chew rarely goes bad, please stop feeding the dog and call us immediately if you see fibrous white/light or green/blue spots on the chew. This is a sign of mold growth and is hazardous. We would appreciate these chews to be placed in a zipper bag and sent to us for testing. In replacement we can sadfsadsaffaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaa a send you a replacement chew right away. knowAlthough Himalayan Dog Chew rarely goes bad, please stop feeding the dog and call us immediately if you see fibrous white/light or green/blue spots on the chew. This is a sign of mold growth and is hazardous. We would appreciate these chews to be placed in a zipper bag and sent to us for testing. In replacement we can sadfsadsaffaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaa a send you a replacement chew right away. knowAlthough Himalayan Dog Chew rarely goes bad, please stop feeding the dog and call us immediately if you see fibrous white/light or '),
(2, '', 'question 2 chew', 'This is a single line faq answer... This is a single line faq answer...  This is a single line faq answer...  This is a single line faq answer... '),
(3, '', 'There is no expiration date on the package, so when does it expire?', 'Our products are packaged using Desi-Pak to absorb any moisture \r\nand oxygen after sealing, preventing any growth of microbes, \r\nas long as packages are sealed and have no tear. \r\nWe have been conducting experiments since September 2007 to determine the expiration dates on Himalayan Dog Chews. We created \r\nsix possible environments for home and retail stores (dry conditions), \r\nand started with twelve Himalayan Dog Chews in each environment. \r\nEvery September, we take one from each sample container \r\nand test for the following:\r\n		â€¢  E. coli	â€¢  Salmonella		â€¢  Mold\r\n		â€¢  Yeast		â€¢  Water activity\r\nIt is safe to say that the HDC has an expiration date of approximately \r\n4 years from the date of opening the package, as long as they \r\nare in dry conditions.');

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

DROP TABLE IF EXISTS `forms`;
CREATE TABLE IF NOT EXISTS `forms` (
  `form_id` int(11) NOT NULL AUTO_INCREMENT,
  `form_name` varchar(255) NOT NULL,
  `form_description` text NOT NULL,
  `form_file` text NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`form_id`, `form_name`, `form_description`, `form_file`) VALUES
(1, 'Map', 'Map', 'forms/map.pdf'),
(2, 'Order Form ', 'Order Form', 'forms/order_form.pdf'),
(3, 'Order form 2012', 'ORder form 2012', 'forms/order_form_12/pdf'),
(4, 'Brochure', 'Brochure', 'forms/brochure.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `member_mtype`
--

DROP TABLE IF EXISTS `member_mtype`;
CREATE TABLE IF NOT EXISTS `member_mtype` (
  `member_mtype` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `membertype_id` int(11) NOT NULL,
  PRIMARY KEY (`member_mtype`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `member_mtype`
--

INSERT INTO `member_mtype` (`member_mtype`, `member_id`, `membertype_id`) VALUES
(1, 3965, 3),
(2, 3967, 3),
(3, 3968, 3),
(4, 3971, 3);

-- --------------------------------------------------------

--
-- Table structure for table `member_types`
--

DROP TABLE IF EXISTS `member_types`;
CREATE TABLE IF NOT EXISTS `member_types` (
  `member_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_type_name` varchar(255) NOT NULL,
  `member_type_description` text NOT NULL,
  PRIMARY KEY (`member_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `member_types`
--

INSERT INTO `member_types` (`member_type_id`, `member_type_name`, `member_type_description`) VALUES
(1, 'employee', 'employee'),
(2, 'distributor', 'distributor'),
(3, 'retailer', 'retailer'),
(4, 'retailer_contacts', 'retailer_contacts'),
(5, 'vendor', 'vendor'),
(6, 'charity', 'charity'),
(7, 'breeder', 'breeder'),
(8, 'customer', 'customer');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `urlKey` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `urlKey` (`urlKey`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`page_id`, `urlKey`, `title`, `content`, `status`) VALUES
(1, 'about-us', 'About Us', '<div class="wrapper">\r\n<div class="leftBody"><img src="../../../..//himalayan/assets/uploads/cms/about-image.png" alt="about-image" /></div>\r\n<div class="rightBody">\r\n<h1>Our History</h1>\r\n<p>Co-founder Nishes Shrestha and Suman Shrestha discovered this healthy dog snack when they met for dinner in 2003. Suman spotted Nishes'' dog chewing in Himalayan hard cheese. Out of curiosity, the founder tried the cheese on their friends'' and families'' dogs. the positive responce encouraged them todo extensive research on cheese for canines, which they engaged in for four years. On September 2, 2007, Himalayan''s first producing Himalayan Dog Chew - was sold at dog show fain in Bellingham, Washington. After producing Himalayan Dog Chews in Nishes'' kitchen for three months, the operation moved to seattle under Sujan Shrestha''s leadersip in January 2008. We now distribute our products to over 5,000 retailers.</p>\r\n<h1>our farmers</h1>\r\n<p>We have created a consortium of rouchly 3,000 farmers in the Himalayas, mostly in Nepal. These farmers are trained, given five to six months'' lead time, and are paid promptly to produce Himalan Dog Chews. Each farmer milks about two to five cows and yaks everyday using traditional methods, without any modern devices. The cattle graze in natural pastures, where present, and are fed all natural leaves from the forest. farmers collect roughly six gallons of milk to make two pounds of Himalayan Dog Chews. On average, each farmer collect about 20 gallons of milk.</p>\r\n<a class="btn btn-blue" href="http://192.168.1.107/himalayan/pages/view/about-team">meet our team</a></div>\r\n</div>', 1),
(3, 'about-team', 'About Our Team', '<div class="wrapper">\r\n<div class="aboutteam"><img src="../../../..//himalayan/assets/uploads/cms/about-team.png" alt="about-team" /><br />\r\n<ul>\r\n<li class="teamHeader">Himalayan Dog Chew Team 2014</li>\r\n<li>top row: Samantha, Amar, Mohamed, Henry, Henry, Joseph, Mohamed, Chris, Brice, Rita, Rocio, Vania, Laura, Julissa, jeremy, nathan</li>\r\n<li>middle row: Brandon, Lane, Renato, Cyrus, Ahmed, Jeff, Mahalis, Zena, Josephine, Andrew, Eyerusalem, Nancy, Grizelda, Fedra, Manisha</li>\r\n<li>bottom row: Jil, Luten, Suman, Bella, Nishes, Astha, Cherelle, Norge, Eddie, Akram, Mango, Derek, Kristi, Milisa</li>\r\n</ul>\r\n<a class="btn btn-blue" href="http://192.168.1.107/himalayan/pages/view/about-us">back</a>\r\n<div class="clearfix">&nbsp;</div>\r\n</div>\r\n<div class="clearfix">&nbsp;</div>\r\n</div>', 1),
(4, 'our-mission', 'Our Mission', '<div class="wrapper">\r\n<div class="half">\r\n<h1>Our Mission</h1>\r\n<p>Himalayan Corporation aspires to become the most prominient company in the pet industry while maintainin and building on our reputation for innovative, healthy, and high quality products. to ensure we uphold these standards in each new enterp[rise, we are driven by a set of core values:</p>\r\n<ul>\r\n<li>Provide exceptional customer service</li>\r\n<li>Treat employees with the utmost respect</li>\r\n<li>Produce and sell products of the highest quality</li>\r\n<li>Maximize savings, satisfaction and value for our customers</li>\r\n<li>Fuel growth through customer referrals, Innovation and reputation</li>\r\n<li>Actively impact the community through our presence and charitable contributions</li>\r\n</ul>\r\n<p>Himalayan Corporation embodies a collection of divers pet products with the highest aspirations.</p>\r\n<h1>Our Vision</h1>\r\n<p>is to be recognized and respected for producin the healthiest and highest quality pet food and products in teh world.</p>\r\n<p><img src="../../../assets/uploads/cms/homepage-banner.png" alt="homepage-banner" /></p>\r\n</div>\r\n</div>', 1),
(5, 'guarantee', 'Guarantee', '<div class="account-menu">\n<ul>\n<li><a href="http://192.168.1.107/himalayan/account/pricing">Pricing</a></li>\n<li><a href="http://192.168.1.107/himalayan/account/forms">Forms</a></li>\n<li><a href="#">Distributors</a></li>\n<li><a href="http://192.168.1.107/himalayan/pages/view/guarantee">Guarantee</a></li>\n<li><a href="http://192.168.1.107/himalayan/pages/view/shipping">Shipping</a></li>\n</ul>\n</div>\nGuarantee Page', 1),
(6, 'shipping', 'Shipping', '<div class="account-menu">\n<ul>\n<li><a href="http://192.168.1.107/himalayan/account/pricing">Pricing</a></li>\n<li><a href="http://192.168.1.107/himalayan/account/forms">Forms</a></li>\n<li><a href="#">Distributors</a></li>\n<li><a href="http://192.168.1.107/himalayan/pages/view/guarantee">Guarantee</a></li>\n<li><a href="http://192.168.1.107/himalayan/pages/view/shipping">Shipping</a></li>\n</ul>\n</div>\nShipping Page', 1),
(7, 'test', 'test', '<p>test</p>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `photo_gallery`
--

DROP TABLE IF EXISTS `photo_gallery`;
CREATE TABLE IF NOT EXISTS `photo_gallery` (
  `photo_id` int(11) NOT NULL AUTO_INCREMENT,
  `photo_image` longtext NOT NULL,
  `photo_image_resized` text NOT NULL,
  `photo_caption` text NOT NULL,
  `photo_status` int(11) NOT NULL,
  PRIMARY KEY (`photo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `photo_gallery`
--

INSERT INTO `photo_gallery` (`photo_id`, `photo_image`, `photo_image_resized`, `photo_caption`, `photo_status`) VALUES
(3, 'photogallery/croppedImg_19055.png', 'photogallery/croppedImg_19055.png', '<p>Nepal Farmers</p>', 1),
(4, 'photogallery/croppedImg_25552.jpeg', 'photogallery/croppedImg_25552.jpeg', '<p>Vito</p>', 1),
(5, 'photogallery/croppedImg_26958.jpeg', 'photogallery/croppedImg_26958.jpeg', '<p>alina</p>', 1),
(7, 'photogallery/croppedImg_12118.jpeg', 'photogallery/croppedImg_12118.jpeg', '<p>bhari1</p>', 1),
(8, 'photogallery/croppedImg_17777.jpeg', 'photogallery/croppedImg_17777.jpeg', '<p>testastaste</p>', 1),
(9, 'photogallery/croppedImg_18200.jpeg', 'photogallery/croppedImg_18200.jpeg', '<p>dfasfd</p>', 1),
(10, 'photogallery/croppedImg_15099.jpeg', 'photogallery/croppedImg_15099.jpeg', '<p>subodh stupid test</p>', 1),
(11, 'photogallery/croppedImg_21642.jpeg', 'photogallery/croppedImg_21642.jpeg', '<p>subodh stupid test</p>', 1),
(12, 'photogallery/croppedImg_28811.jpeg', 'photogallery/croppedImg_28811.jpeg', '<p>subodh stupid test</p>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products_simple`
--

DROP TABLE IF EXISTS `products_simple`;
CREATE TABLE IF NOT EXISTS `products_simple` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(255) NOT NULL,
  `psku` varchar(255) NOT NULL,
  `ptype` int(11) NOT NULL,
  `product_asid` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `in_stock` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `is_variation` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pid`),
  KEY `ptype` (`ptype`,`product_asid`),
  KEY `product_asid` (`product_asid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=124 ;

--
-- Dumping data for table `products_simple`
--

INSERT INTO `products_simple` (`pid`, `pname`, `psku`, `ptype`, `product_asid`, `quantity`, `in_stock`, `status`, `is_variation`) VALUES
(8, 'HDC Blue', 'hdc_blue_old', 1, 10, 100, 1, 0, 0),
(9, 'HDC Gray', 'hdc_gray_old', 1, 10, 100, 1, 0, 0),
(55, 'Test Product', 'test', 1, 10, 1111, 1, 0, 0),
(57, 'New Product', 'newp', 1, 10, 100, 1, 0, 0),
(72, 'Yaky Crunch 1.25 ox box', 'yaky_crunch_1.25_old', 1, 12, 100, 1, 0, 1),
(73, 'Yaky Crunch 3 ox box', 'yaky_crunch_3_old', 1, 12, 100, 1, 0, 1),
(74, 'Yaky Crunch', 'yaky_crunch_old', 2, 12, 0, 0, 0, 0),
(75, 'Test Variation', 'vari1', 1, 12, 100, 0, 0, 1),
(81, 'test variation again', 'tva', 1, 12, 111, 1, 0, 1),
(84, 'HDC Blue', 'hdc_blue', 1, 10, 100, 1, 1, 0),
(85, 'HDC Gray', 'hdc_gray', 1, 10, 100, 1, 1, 0),
(86, 'HDC Green', 'hdc_green', 1, 10, 100, 1, 1, 0),
(87, 'HDC Red', 'hdc_red', 1, 10, 100, 1, 1, 0),
(88, 'HDC Seasoning', 'hdc_seasoning', 1, 11, 100, 1, 1, 0),
(89, 'Yaky Crunch 1.25 oz box', 'yaky_crunch_125', 1, 12, 100, 1, 1, 1),
(90, 'Yaky Crunch 3 oz box', 'yaky_crunch_3', 1, 12, 100, 1, 1, 1),
(94, 'Yaky Crunch', 'yaky_crunch', 2, 12, 0, 0, 1, 0),
(95, 'HDC Yellow', 'hdc_yellow', 1, 10, 100, 1, 1, 0),
(96, 'Yaky Nugget', 'yaky_nugget', 1, 13, 100, 1, 1, 0),
(97, 'Yaky Puff', 'yaky_puff', 1, 14, 100, 1, 1, 0),
(98, 'Yaky Sticks 6', 'yaky_stick_6', 1, 15, 100, 1, 1, 1),
(99, 'Yaky Sticks 12', 'yaky_stick_12', 1, 15, 100, 1, 1, 1),
(100, 'Yaky Sticks', 'yaky_sticks', 2, 15, 0, 0, 1, 0),
(101, 'Yaky Yam FF 4 oz box', 'yaky_yam_ff_4oz', 1, 16, 100, 1, 1, 1),
(102, 'Yaky Yam FF 14 oz box', 'yaky_yam_ff_14oz', 1, 16, 100, 1, 1, 1),
(103, 'Fruity Fruit', 'yaky_yam_fruity_fruit', 2, 16, 0, 0, 1, 0),
(104, 'Yaky Yams Lotsa Chicken 4 oz box', 'yaky_yam_ff_4oz', 1, 16, 100, 1, 1, 1),
(105, 'Yaky Yam LC 14 oz box', 'yaky_yam_lc_14oz', 1, 16, 100, 1, 1, 1),
(106, 'Lotsa Chicken', 'yaky_yam_lotsa_chicken', 2, 16, 0, 0, 1, 0),
(107, 'Yaky Yam VV 4 oz', 'yaky_yam_vv_4oz', 1, 16, 100, 1, 1, 1),
(108, 'Yaky Yam VV 14 oz', 'yaky_yam_vv_14', 1, 16, 100, 1, 1, 1),
(109, 'Very Veggie', 'yaky_yam_very_veggie', 2, 16, 0, 0, 1, 0),
(118, 'Yaky Sticks', 'yaky_sticks_new', 1, 15, 100, 1, 0, 0),
(120, 'daf', 'adfa', 2, 10, 0, 0, 0, 0),
(121, 'LINa', 'asdfas', 1, 10, 0, 1, 0, 0),
(123, 'aas', 'adsfa', 2, 11, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_associations`
--

DROP TABLE IF EXISTS `product_associations`;
CREATE TABLE IF NOT EXISTS `product_associations` (
  `paid` int(11) NOT NULL AUTO_INCREMENT,
  `parent_pid` int(11) NOT NULL,
  `associate_pid` int(11) NOT NULL,
  PRIMARY KEY (`paid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=145 ;

--
-- Dumping data for table `product_associations`
--

INSERT INTO `product_associations` (`paid`, `parent_pid`, `associate_pid`) VALUES
(42, 74, 72),
(43, 74, 73),
(44, 74, 81),
(77, 111, 110),
(79, 113, 75),
(129, 119, 72),
(131, 120, 72),
(134, 123, 72),
(135, 109, 107),
(136, 109, 108),
(137, 106, 104),
(138, 106, 105),
(139, 103, 101),
(140, 103, 102),
(141, 100, 98),
(142, 100, 99),
(143, 94, 89),
(144, 94, 90);

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_values_gallery`
--

DROP TABLE IF EXISTS `product_attribute_values_gallery`;
CREATE TABLE IF NOT EXISTS `product_attribute_values_gallery` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `pavg_pid` int(11) NOT NULL,
  `value` text NOT NULL,
  `is_base_image` int(11) NOT NULL,
  `is_thumbnail_image` int(11) NOT NULL,
  PRIMARY KEY (`gid`),
  KEY `pavg_pid` (`pavg_pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=195 ;

--
-- Dumping data for table `product_attribute_values_gallery`
--

INSERT INTO `product_attribute_values_gallery` (`gid`, `pavg_pid`, `value`, `is_base_image`, `is_thumbnail_image`) VALUES
(37, 57, 'products/croppedImg_9876.jpeg', 0, 0),
(38, 57, 'products/croppedImg_21436.jpeg', 0, 0),
(45, 72, 'products/croppedImg_29832.jpeg', 0, 0),
(46, 73, 'products/croppedImg_15905.jpeg', 0, 0),
(47, 73, 'products/croppedImg_12870.png', 0, 0),
(48, 74, 'products/croppedImg_30763.jpeg', 0, 0),
(50, 75, 'products/croppedImg_20788.jpeg', 0, 0),
(52, 74, 'products/croppedImg_12450.jpeg', 0, 0),
(55, 81, 'products/croppedImg_2864.jpeg', 0, 0),
(57, 9, 'products/croppedImg_973.jpeg', 0, 0),
(59, 55, 'products/croppedImg_18100.jpeg', 0, 0),
(65, 89, 'products/croppedImg_26989.jpeg', 0, 0),
(66, 90, 'products/croppedImg_18850.jpeg', 0, 0),
(79, 104, 'products/croppedImg_24609.jpeg', 0, 0),
(80, 105, 'products/croppedImg_11334.jpeg', 0, 0),
(82, 107, 'products/croppedImg_23348.jpeg', 0, 0),
(83, 108, 'products/croppedImg_23901.jpeg', 0, 0),
(139, 118, 'products/doctor_who_time_of_the_doctor-1920x1080.jpg', 0, 0),
(142, 84, 'products/chews_blue_03.png', 0, 1),
(143, 85, 'products/chews_gray_03.png', 0, 1),
(145, 87, 'products/chews_red_03.png', 0, 1),
(146, 95, 'products/chews_yellow_03.png', 0, 1),
(147, 86, 'products/chews_green_03.png', 0, 1),
(149, 88, 'products/creations_seasoning_03.png', 0, 1),
(150, 96, 'products/creations_YN_03.png', 0, 1),
(151, 97, 'products/creations_YP_03.png', 0, 1),
(152, 94, 'products/creations_YC_03.png', 0, 1),
(153, 102, 'products/creations_YY_FF_03.png', 0, 0),
(154, 101, 'products/creations_YY_FF_03.png', 0, 0),
(155, 103, 'products/creations_YY_FF_03.png', 0, 1),
(156, 106, 'products/creations_YY_LC_03.png', 0, 1),
(157, 109, 'products/creations_YY_VV_03.png', 0, 1),
(160, 98, 'products/creations_YS_6_03.png', 0, 1),
(161, 99, 'products/creations_YS_12_03.png', 0, 1),
(162, 100, 'products/creations_YS_03.png', 0, 0),
(163, 84, 'products/retailer_pricing_blue_03.png', 1, 0),
(164, 85, 'products/retailer_pricing_gray_03.png', 1, 0),
(165, 86, 'products/retailer_pricing_green_03.png', 1, 0),
(167, 95, 'products/retailer_pricing_yellow_03.png', 1, 0),
(170, 88, 'products/retailer_pricing_Seasoning_03.png', 1, 0),
(171, 94, 'products/retailer_pricing_YC_03.png', 1, 0),
(172, 96, 'products/retailer_pricing_YN_03.png', 1, 0),
(173, 97, 'products/retailer_pricing_YP_03.png', 1, 0),
(174, 100, 'products/retailer_pricing_YS_03.png', 1, 0),
(175, 103, 'products/retailer_pricing_YYFF_03.png', 1, 0),
(176, 106, 'products/retailer_pricing_YYLC_03.png', 1, 0),
(177, 109, 'products/retailer_pricing_YYVV_03.png', 1, 0),
(182, 120, 'products/Koala.jpg', 0, 0),
(183, 120, 'products/Jellyfish.jpg', 1, 0),
(184, 118, 'products/Koala.jpg', 0, 1),
(185, 118, 'products/Jellyfish.jpg', 1, 0),
(186, 121, 'products/Jellyfish.jpg', 0, 1),
(187, 121, 'products/Hydrangeas.jpg', 1, 0),
(188, 120, 'products/Lighthouse.jpg', 0, 1),
(189, 123, 'products/Penguins.jpg', 0, 0),
(190, 123, 'products/Jellyfish.jpg', 0, 0),
(191, 123, 'products/Tulips.jpg', 0, 1),
(194, 87, 'products/retailer_pricing_red_03.png', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_values_int`
--

DROP TABLE IF EXISTS `product_attribute_values_int`;
CREATE TABLE IF NOT EXISTS `product_attribute_values_int` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pavi_pid` int(11) NOT NULL,
  `pavi_aid` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pavi_pid` (`pavi_pid`,`pavi_aid`),
  KEY `pavi_aid` (`pavi_aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1400 ;

--
-- Dumping data for table `product_attribute_values_int`
--

INSERT INTO `product_attribute_values_int` (`id`, `pavi_pid`, `pavi_aid`, `value`) VALUES
(320, 75, 15, 111),
(321, 75, 18, 0),
(322, 75, 19, 0),
(323, 75, 20, 2),
(324, 75, 21, 2),
(325, 81, 15, 0),
(326, 81, 18, 0),
(327, 81, 19, 0),
(328, 81, 20, 0),
(329, 81, 21, 0),
(345, 57, 18, 1),
(346, 57, 19, 2),
(347, 57, 22, 100),
(356, 55, 18, 1),
(357, 55, 19, 2),
(358, 55, 20, 1),
(359, 55, 21, 2),
(372, 73, 15, 3),
(373, 73, 18, 200),
(374, 73, 19, 220),
(375, 73, 20, 2),
(376, 73, 21, 2),
(377, 72, 15, 1),
(378, 72, 18, 75),
(379, 72, 19, 80),
(380, 72, 20, 2),
(381, 72, 21, 2),
(519, 8, 18, 3),
(520, 8, 19, 4),
(521, 8, 20, 359),
(522, 8, 21, 359),
(706, 9, 18, 1),
(707, 9, 19, 1),
(708, 9, 20, 614),
(709, 9, 21, 618),
(1011, 108, 15, 14),
(1012, 108, 18, 140),
(1013, 108, 19, 146),
(1014, 108, 20, 8),
(1015, 108, 21, 11),
(1053, 105, 15, 14),
(1054, 105, 18, 140),
(1055, 105, 19, 146),
(1056, 105, 20, 8),
(1057, 105, 21, 11),
(1216, 90, 15, 3),
(1217, 90, 18, 200),
(1218, 90, 19, 220),
(1219, 90, 20, 2),
(1220, 90, 21, 2),
(1221, 89, 15, 1),
(1222, 89, 18, 75),
(1223, 89, 19, 80),
(1224, 89, 20, 2),
(1225, 89, 21, 2),
(1226, 102, 15, 14),
(1227, 102, 18, 140),
(1228, 102, 19, 146),
(1229, 102, 20, 8),
(1230, 102, 21, 11),
(1303, 118, 20, 12),
(1304, 118, 21, 14),
(1305, 118, 24, 123),
(1306, 118, 25, 12),
(1307, 121, 18, 32432),
(1308, 121, 19, 324),
(1309, 121, 20, 234),
(1310, 121, 21, 234),
(1327, 95, 18, 3),
(1328, 95, 19, 3),
(1329, 95, 20, 1179),
(1330, 95, 21, 1179),
(1335, 98, 20, 304),
(1336, 98, 21, 304),
(1337, 98, 24, 12),
(1338, 98, 25, 6),
(1339, 97, 18, 12),
(1340, 97, 19, 13),
(1341, 97, 20, 16),
(1342, 97, 21, 18),
(1343, 96, 18, 21),
(1344, 96, 19, 24),
(1345, 96, 20, 17),
(1346, 96, 21, 20),
(1354, 86, 18, 1),
(1355, 86, 19, 1),
(1356, 86, 20, 256),
(1357, 86, 21, 256),
(1362, 85, 18, 1),
(1363, 85, 19, 1),
(1364, 85, 20, 614),
(1365, 85, 21, 614),
(1366, 84, 18, 3),
(1367, 84, 19, 4),
(1368, 84, 20, 359),
(1369, 84, 21, 359),
(1370, 87, 18, 1),
(1371, 87, 19, 1),
(1372, 87, 20, 359),
(1373, 87, 21, 359),
(1374, 88, 15, 2),
(1375, 88, 20, 204),
(1376, 88, 21, 204),
(1381, 99, 20, 152),
(1382, 99, 21, 152),
(1383, 99, 24, 12),
(1384, 99, 25, 12),
(1385, 104, 15, 4),
(1386, 104, 18, 40),
(1387, 104, 19, 43),
(1388, 104, 20, 8),
(1389, 104, 21, 11),
(1390, 101, 15, 4),
(1391, 101, 18, 40),
(1392, 101, 19, 43),
(1393, 101, 20, 8),
(1394, 101, 21, 11),
(1395, 107, 15, 4),
(1396, 107, 18, 40),
(1397, 107, 19, 43),
(1398, 107, 20, 8),
(1399, 107, 21, 11);

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_values_select`
--

DROP TABLE IF EXISTS `product_attribute_values_select`;
CREATE TABLE IF NOT EXISTS `product_attribute_values_select` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pavs_pid` int(11) NOT NULL,
  `pavs_aid` int(11) NOT NULL,
  `pavs_vid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pavs_pid` (`pavs_pid`,`pavs_aid`,`pavs_vid`),
  KEY `pavs_aid` (`pavs_aid`),
  KEY `pavs_vid` (`pavs_vid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=993 ;

--
-- Dumping data for table `product_attribute_values_select`
--

INSERT INTO `product_attribute_values_select` (`id`, `pavs_pid`, `pavs_aid`, `pavs_vid`) VALUES
(409, 8, 9, 43),
(410, 8, 23, 62),
(512, 9, 9, 47),
(513, 9, 23, 62),
(280, 55, 9, 43),
(281, 55, 23, 60),
(274, 57, 9, 43),
(275, 57, 23, 62),
(293, 72, 9, 43),
(294, 72, 16, 52),
(295, 72, 17, 54),
(296, 72, 23, 60),
(297, 72, 29, 66),
(288, 73, 9, 43),
(289, 73, 16, 52),
(290, 73, 17, 54),
(291, 73, 23, 60),
(292, 73, 29, 67),
(254, 75, 9, 43),
(255, 75, 16, 52),
(256, 75, 17, 54),
(257, 75, 23, 60),
(258, 75, 29, 66),
(259, 81, 9, 43),
(260, 81, 16, 52),
(261, 81, 17, 54),
(262, 81, 23, 60),
(263, 81, 29, 66),
(964, 84, 9, 43),
(965, 84, 23, 62),
(962, 85, 9, 47),
(963, 85, 23, 62),
(958, 86, 9, 44),
(959, 86, 23, 62),
(966, 87, 9, 45),
(967, 87, 23, 62),
(968, 88, 9, 70),
(969, 88, 16, 52),
(970, 88, 17, 55),
(971, 88, 23, 61),
(868, 89, 9, 70),
(869, 89, 16, 52),
(870, 89, 17, 54),
(871, 89, 23, 60),
(872, 89, 29, 66),
(863, 90, 9, 70),
(864, 90, 16, 52),
(865, 90, 17, 54),
(866, 90, 23, 60),
(867, 90, 29, 67),
(940, 95, 9, 46),
(941, 95, 23, 62),
(950, 96, 9, 70),
(951, 96, 23, 62),
(948, 97, 9, 70),
(949, 97, 23, 62),
(945, 98, 9, 69),
(946, 98, 23, 62),
(947, 98, 26, 59),
(975, 99, 9, 48),
(976, 99, 23, 62),
(977, 99, 26, 59),
(983, 101, 9, 70),
(984, 101, 16, 52),
(985, 101, 17, 54),
(986, 101, 23, 62),
(987, 101, 33, 71),
(873, 102, 9, 70),
(874, 102, 16, 52),
(875, 102, 17, 54),
(876, 102, 23, 62),
(877, 102, 33, 72),
(978, 104, 9, 70),
(979, 104, 16, 52),
(980, 104, 17, 54),
(981, 104, 23, 62),
(982, 104, 33, 71),
(740, 105, 9, 70),
(741, 105, 16, 52),
(742, 105, 17, 54),
(743, 105, 23, 60),
(744, 105, 33, 72),
(988, 107, 9, 70),
(989, 107, 16, 52),
(990, 107, 17, 54),
(991, 107, 23, 62),
(992, 107, 33, 71),
(701, 108, 9, 70),
(702, 108, 16, 52),
(703, 108, 17, 54),
(704, 108, 23, 62),
(705, 108, 33, 72),
(927, 118, 9, 43),
(928, 118, 23, 62),
(929, 118, 26, 59),
(930, 121, 9, 43),
(931, 121, 23, 60);

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_values_text`
--

DROP TABLE IF EXISTS `product_attribute_values_text`;
CREATE TABLE IF NOT EXISTS `product_attribute_values_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pavt_pid` int(11) NOT NULL,
  `pavt_aid` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pavt_pid` (`pavt_pid`,`pavt_aid`),
  KEY `pavt_aid` (`pavt_aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1156 ;

--
-- Dumping data for table `product_attribute_values_text`
--

INSERT INTO `product_attribute_values_text` (`id`, `pavt_pid`, `pavt_aid`, `value`) VALUES
(193, 75, 10, '<p>test</p>'),
(194, 75, 11, '<p>test</p>'),
(195, 81, 10, '<p>test</p>'),
(196, 81, 11, '<p>test</p>'),
(207, 57, 10, '<p><img src="../../../assets/uploads/cms/Lighthouse.jpg" alt="Lighthouse" />test</p>'),
(208, 57, 11, '<p>test</p>'),
(213, 55, 10, '<p>test</p>'),
(214, 55, 11, '<p>test</p>'),
(221, 73, 10, '<p>test</p>'),
(222, 73, 11, '<p>test</p>'),
(223, 72, 10, '<p>test</p>'),
(224, 72, 11, '<p>test</p>'),
(331, 8, 10, '<p>Ingredients1</p>'),
(332, 8, 11, '<p>GA</p>'),
(333, 8, 32, ''),
(334, 8, 34, '<p>Himalayan Dog Chews</p>'),
(519, 9, 10, '<p><img src="../../../assets/uploads/cms/Koala.jpg" alt="Koala" />Ingredients</p>'),
(520, 9, 11, '<p>AG</p>'),
(521, 9, 32, ''),
(522, 9, 34, '<p>Himalayan Dog Chews</p>'),
(845, 108, 10, '<p>Yak &amp; Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice</p>'),
(846, 108, 11, '<p>Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%</p>'),
(847, 108, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(848, 108, 34, '<p>Yaky Yams - available in 4 oz boxes and 14 oz boxes</p>'),
(849, 108, 36, '<p><strong>Yaky Yam Very Veggie</strong> has Vegetables that contains essential nutrients for your best friends'' to keep them healthy. Vegetables help them:</p>\r\n<ul type="disc">\r\n<li>To form required red blood cells.</li>\r\n<li>To reduce the risk of kidney stones.</li>\r\n<li>To assist their bowel functions.</li>\r\n<li>To maintain healthy skin and hair</li>\r\n</ul>'),
(890, 105, 10, '<p>Yak &amp; Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice</p>'),
(891, 105, 11, '<p>Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%</p>'),
(892, 105, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(893, 105, 34, '<p>Yaky Yams - available in 4 oz boxes and 14 oz boxes</p>'),
(894, 105, 36, '<p><strong>Yaky Yam Lotsa Chicken</strong> contains additional protein to supplement your best friends&rsquo; diet. Protein helps them:</p>\r\n<ul type="disc">\r\n<li>To create new muscles for young dogs</li>\r\n<li>To rebuild muscles for performance dogs</li>\r\n<li>To produce milk for lactating mothers</li>\r\n<li>To fulfill diet requirments for diabetic dogs</li>\r\n</ul>'),
(1021, 90, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1022, 90, 34, '<p>Yaky Crunch - available in 1.25 oz boxes and 3 oz boxes</p>'),
(1023, 90, 36, ''),
(1024, 89, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1025, 89, 34, ''),
(1026, 89, 36, ''),
(1027, 102, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1028, 102, 34, '<p>Yaky Yams - available in 4 oz boxes and 14 oz boxes</p>'),
(1029, 102, 36, '<p><strong>Yaky Yam Fruity Fruit</strong> has fruits that contains essential minerals and vitamins to protect your best friends'' from diseases. Fruits help them:</p>\r\n<ul type="disc">\r\n<li>To fight chronic diseases such as Cancer</li>\r\n<li>To regulate blood circulation</li>\r\n<li>To boost their immune system</li>\r\n<li>To reduce cholesterol</li>\r\n</ul>'),
(1084, 118, 32, '<p>Wholesakle:$10</p>'),
(1085, 118, 34, '<p>sdafasdf</p>'),
(1086, 118, 36, ''),
(1087, 121, 32, '<p>234</p>'),
(1088, 121, 34, '<p>2434</p>'),
(1089, 121, 36, '<p>234</p>'),
(1102, 95, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1103, 95, 34, '<p>Himalayan Dog Chews</p>'),
(1104, 95, 36, '<h2>Why is it so special?</h2>\r\n<p>Himalayan Dog Chew is a very hard chew. Although cheese, it is sometimes popularly reffered to as Concrete, Glass, Wood and Metal. Depending on the size and eating habits of the dog, this is a very long lasting dog chew that you can find. Dogs must work the end of the treat for hours, softening it with their mouths before small parts of it can be slowly scraped off. <br /><br />Himalayan Dog Chew is 100% natural with no preservatives. It is an authentic type of cheese eaten by the people of the Himalayas. When you give this chew to your dog, you know that you are providing them with hours of high quality eating entertainment. <br /><br />We, here at Himalayan Dog Chew, believe very strongly in the potential for this product to become a household name, and we look forward to sharing our discovery with other dog owners. If this has piqued your interest or you have any further questions about Himalayan Dog Chew, please do not hesitate to contact us.</p>'),
(1108, 98, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1109, 98, 34, '<p>Yaky Sticks - available in 12" and 6"</p>'),
(1110, 98, 36, ''),
(1111, 97, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1112, 97, 34, '<p>Yaky Puff</p>'),
(1113, 97, 36, '<h2>Why is it so Special?</h2>\r\n<p>Cheese contains enzymes that help remove plaques from their teeth which eventually discourages tooth decay, gingivitis and bacterial growth. Yaky Puff are easier to chew and dissolves in the dogs mouth, that speeds up the effect of the cheese that Himalayan Dog Chew provide. Moreover, because of the strong smoked flavor, our research have shown that this is by far the best rewarding treats for dogs.</p>'),
(1114, 96, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1115, 96, 34, '<p>Yaky Nugget</p>'),
(1116, 96, 36, '<h2>Why is it so Special?</h2>\r\n<p>Cheese contains enzymes that help remove plaques from their teeth which eventually discourages tooth decay, gingivitis and bacterial growth. Yaky Puff are easier to chew and dissolves in the dogs mouth, that speeds up the effect of the cheese that Himalayan Dog Chew provide. Moreover, because of the strong smoked flavor, our research have shown that this is by far the best rewarding treats for dogs.</p>'),
(1123, 86, 32, '<p>Wholesale Price : $4.15</p>\r\n<p>Discounted Price : $4.00</p>\r\n<p>MSRP : $7.99</p>'),
(1124, 86, 34, '<p>Himalayan Dog Chews</p>'),
(1125, 86, 36, '<h2>Why is it so special?</h2>\r\n<p>Himalayan Dog Chew is a very hard chew. Although cheese, it is sometimes popularly reffered to as Concrete, Glass, Wood and Metal. Depending on the size and eating habits of the dog, this is a very long lasting dog chew that you can find. Dogs must work the end of the treat for hours, softening it with their mouths before small parts of it can be slowly scraped off. <br /><br />Himalayan Dog Chew is 100% natural with no preservatives. It is an authentic type of cheese eaten by the people of the Himalayas. When you give this chew to your dog, you know that you are providing them with hours of high quality eating entertainment. <br /><br />We, here at Himalayan Dog Chew, believe very strongly in the potential for this product to become a household name, and we look forward to sharing our discovery with other dog owners. If this has piqued your interest or you have any further questions about Himalayan Dog Chew, please do not hesitate to contact us.</p>'),
(1129, 85, 32, '<p>Wholesale Price : $8.80</p>\r\n<p>Discounted Price : $8.60</p>\r\n<p>MSRP : $17.99</p>'),
(1130, 85, 34, '<p>Himalayan Dog Chews</p>'),
(1131, 85, 36, '<h2>Why is it so special?</h2>\r\n<p>Himalayan Dog Chew is a very hard chew. Although cheese, it is sometimes popularly reffered to as Concrete, Glass, Wood and Metal. Depending on the size and eating habits of the dog, this is a very long lasting dog chew that you can find. Dogs must work the end of the treat for hours, softening it with their mouths before small parts of it can be slowly scraped off. <br /><br />Himalayan Dog Chew is 100% natural with no preservatives. It is an authentic type of cheese eaten by the people of the Himalayas. When you give this chew to your dog, you know that you are providing them with hours of high quality eating entertainment. <br /><br />We, here at Himalayan Dog Chew, believe very strongly in the potential for this product to become a household name, and we look forward to sharing our discovery with other dog owners. If this has piqued your interest or you have any further questions about Himalayan Dog Chew, please do not hesitate to contact us.</p>'),
(1132, 84, 32, '<p>Wholesale Price : $5.15</p>\r\n<p>Discounted Price : $5.00</p>\r\n<p>MSRP : $9.99</p>'),
(1133, 84, 34, '<p>Himalayan Dog Chews</p>'),
(1134, 84, 36, '<h2>Why is it so special?</h2>\r\n<p>Himalayan Dog Chew is a very hard chew. Although cheese, it is sometimes popularly reffered to as Concrete, Glass, Wood and Metal. Depending on the size and eating habits of the dog, this is a very long lasting dog chew that you can find. Dogs must work the end of the treat for hours, softening it with their mouths before small parts of it can be slowly scraped off. <br /><br />Himalayan Dog Chew is 100% natural with no preservatives. It is an authentic type of cheese eaten by the people of the Himalayas. When you give this chew to your dog, you know that you are providing them with hours of high quality eating entertainment. <br /><br />We, here at Himalayan Dog Chew, believe very strongly in the potential for this product to become a household name, and we look forward to sharing our discovery with other dog owners. If this has piqued your interest or you have any further questions about Himalayan Dog Chew, please do not hesitate to contact us.</p>'),
(1135, 87, 32, '<p>Wholesale Price : $5.15</p>\r\n<p>Discounted Price : $5.00</p>\r\n<p>MSRP : $9.99</p>'),
(1136, 87, 34, '<p>Himalayan Dog Chews</p>'),
(1137, 87, 36, '<h2>Why is it so special?</h2>\r\n<p>Himalayan Dog Chew is a very hard chew. Although cheese, it is sometimes popularly reffered to as Concrete, Glass, Wood and Metal. Depending on the size and eating habits of the dog, this is a very long lasting dog chew that you can find. Dogs must work the end of the treat for hours, softening it with their mouths before small parts of it can be slowly scraped off. <br /><br />Himalayan Dog Chew is 100% natural with no preservatives. It is an authentic type of cheese eaten by the people of the Himalayas. When you give this chew to your dog, you know that you are providing them with hours of high quality eating entertainment. <br /><br />We, here at Himalayan Dog Chew, believe very strongly in the potential for this product to become a household name, and we look forward to sharing our discovery with other dog owners. If this has piqued your interest or you have any further questions about Himalayan Dog Chew, please do not hesitate to contact us.</p>'),
(1138, 88, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1139, 88, 34, '<p>HDC Sesoning</p>'),
(1140, 88, 36, '<p>test</p>'),
(1144, 99, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1145, 99, 34, '<p>Yaky Sticks - available in 12" and 6"</p>'),
(1146, 99, 36, ''),
(1147, 104, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1148, 104, 34, '<p>Yaky Yams - available in 4 oz boxes and 14 oz boxes</p>'),
(1149, 104, 36, '<p><strong>Yaky Yam Lotsa Chicken</strong> contains additional protein to supplement your best friends&rsquo; diet. Protein helps them:</p>\n<ul type="disc">\n<li>To create new muscles for young dogs</li>\n<li>To rebuild muscles for performance dogs</li>\n<li>To produce milk for lactating mothers</li>\n<li>To fulfill diet requirments for diabetic dogs</li>\n</ul>'),
(1150, 101, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1151, 101, 34, '<p>Yaky Yams - available in 4 oz boxes and 14 oz boxes</p>'),
(1152, 101, 36, '<p><strong>Yaky Yam Fruity Fruit</strong> has fruits that contains essential minerals and vitamins to protect your best friends'' from diseases. Fruits help them:</p>\r\n<ul type="disc">\r\n<li>To fight chronic diseases such as Cancer</li>\r\n<li>To regulate blood circulation</li>\r\n<li>To boost their immune system</li>\r\n<li>To reduce cholesterol</li>\r\n</ul>'),
(1153, 107, 32, '<p>Wholesale Price: $1.85</p>\r\n<p>Discounted Price: $1.75</p>\r\n<p>MSRP: $3.99</p>'),
(1154, 107, 34, '<p>Yaky Yams - available in 4 oz boxes and 14 oz boxes</p>'),
(1155, 107, 36, '<p><strong>Yaky Yam Very Veggie</strong> has Vegetables that contains essential nutrients for your best friends'' to keep them healthy. Vegetables help them:</p>\r\n<ul type="disc">\r\n<li>To form required red blood cells.</li>\r\n<li>To reduce the risk of kidney stones.</li>\r\n<li>To assist their bowel functions.</li>\r\n<li>To maintain healthy skin and hair</li>\r\n</ul>');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_values_varchar`
--

DROP TABLE IF EXISTS `product_attribute_values_varchar`;
CREATE TABLE IF NOT EXISTS `product_attribute_values_varchar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pavv_pid` int(11) NOT NULL,
  `pavv_aid` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pavt_pid` (`pavv_pid`,`pavv_aid`),
  KEY `pavt_aid` (`pavv_aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=340 ;

--
-- Dumping data for table `product_attribute_values_varchar`
--

INSERT INTO `product_attribute_values_varchar` (`id`, `pavv_pid`, `pavv_aid`, `value`) VALUES
(8, 9, 35, '75 lbs'),
(93, 108, 35, ''),
(102, 105, 35, ''),
(205, 90, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(206, 90, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(207, 90, 35, ''),
(208, 89, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(209, 89, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(210, 89, 35, ''),
(211, 102, 10, ''),
(212, 102, 11, ''),
(213, 102, 35, ''),
(268, 118, 10, ''),
(269, 118, 11, ''),
(270, 118, 35, 'stc'),
(271, 121, 10, 'asdf'),
(272, 121, 11, 'dsfads'),
(273, 121, 35, '243'),
(286, 95, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(287, 95, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(288, 95, 35, '65 lbs'),
(292, 98, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(293, 98, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(294, 98, 35, '25 lbs'),
(295, 97, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(296, 97, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(297, 97, 35, ''),
(298, 96, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(299, 96, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(300, 96, 35, ''),
(307, 86, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(308, 86, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(309, 86, 35, '35 lbs'),
(313, 85, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(314, 85, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(315, 85, 35, '75 lbs'),
(316, 84, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(317, 84, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(318, 84, 35, '15 lbs'),
(319, 87, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(320, 87, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(321, 87, 35, '55 lbs'),
(322, 88, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(323, 88, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(324, 88, 35, ''),
(328, 99, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(329, 99, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(330, 99, 35, '50 lbs'),
(331, 104, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(332, 104, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(333, 104, 35, ''),
(334, 101, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(335, 101, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(336, 101, 35, ''),
(337, 107, 10, 'Yak & Cow Milk, Sweet Potato, Carrot, Garbanzo Flour, Cabbage, Broccoli, Celery, Green Bean, Flax Seed, Salt and Lime Juice'),
(338, 107, 11, 'Crude Protein Min 35.10%. Crude Fat Min 15.90%. Dietary fiber max 5.80%. Moisture Max 7.90%. Ash Max 3.60%'),
(339, 107, 35, '');

-- --------------------------------------------------------

--
-- Table structure for table `product_cat`
--

DROP TABLE IF EXISTS `product_cat`;
CREATE TABLE IF NOT EXISTS `product_cat` (
  `pc_id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `doi` datetime NOT NULL,
  PRIMARY KEY (`pc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=268 ;

--
-- Dumping data for table `product_cat`
--

INSERT INTO `product_cat` (`pc_id`, `pid`, `category_id`, `doi`) VALUES
(239, 119, 1, '0000-00-00 00:00:00'),
(242, 118, 7, '0000-00-00 00:00:00'),
(243, 121, 1, '0000-00-00 00:00:00'),
(244, 120, 1, '0000-00-00 00:00:00'),
(248, 123, 1, '0000-00-00 00:00:00'),
(252, 95, 1, '0000-00-00 00:00:00'),
(253, 109, 6, '0000-00-00 00:00:00'),
(254, 106, 6, '0000-00-00 00:00:00'),
(255, 103, 6, '0000-00-00 00:00:00'),
(256, 100, 7, '0000-00-00 00:00:00'),
(257, 97, 4, '0000-00-00 00:00:00'),
(258, 96, 3, '0000-00-00 00:00:00'),
(259, 94, 5, '0000-00-00 00:00:00'),
(262, 86, 1, '0000-00-00 00:00:00'),
(264, 85, 1, '0000-00-00 00:00:00'),
(265, 84, 1, '0000-00-00 00:00:00'),
(266, 87, 1, '0000-00-00 00:00:00'),
(267, 88, 2, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ptype`
--

DROP TABLE IF EXISTS `ptype`;
CREATE TABLE IF NOT EXISTS `ptype` (
  `ptid` int(11) NOT NULL AUTO_INCREMENT,
  `type_code` varchar(255) NOT NULL,
  `type_name` varchar(255) NOT NULL,
  PRIMARY KEY (`ptid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ptype`
--

INSERT INTO `ptype` (`ptid`, `type_code`, `type_name`) VALUES
(1, 'simple', 'Simple Product'),
(2, 'configurable', 'Configurable Product');

-- --------------------------------------------------------

--
-- Table structure for table `retailer_contacts`
--

DROP TABLE IF EXISTS `retailer_contacts`;
CREATE TABLE IF NOT EXISTS `retailer_contacts` (
  `retailer_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `retailer_designation` text NOT NULL,
  PRIMARY KEY (`retailer_contact_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `retailer_contacts`
--

INSERT INTO `retailer_contacts` (`retailer_contact_id`, `rid`, `mid`, `retailer_designation`) VALUES
(2, 3942, 3969, 'CEO1'),
(3, 3942, 3970, 'Manager'),
(4, 3968, 3970, 'test'),
(6, 0, 3973, 'adsfdsa'),
(7, 3942, 3974, 'dsfa');

-- --------------------------------------------------------

--
-- Table structure for table `user_session`
--

DROP TABLE IF EXISTS `user_session`;
CREATE TABLE IF NOT EXISTS `user_session` (
  `session_id` int(100) NOT NULL AUTO_INCREMENT,
  `user_id` int(100) NOT NULL,
  `token_id` varchar(100) NOT NULL,
  `session_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `user_session`
--

INSERT INTO `user_session` (`session_id`, `user_id`, `token_id`, `session_time`) VALUES
(10, 3965, 'alina@gmai.com', '2014-08-14 18:46:09'),
(15, 3956, 'rojan_neo@customer.com', '2014-08-20 10:11:03');

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
CREATE TABLE IF NOT EXISTS `widgets` (
  `widget_id` int(11) NOT NULL AUTO_INCREMENT,
  `widget_name` varchar(255) NOT NULL,
  `widget_identifier` varchar(255) NOT NULL,
  `widget_title` varchar(255) NOT NULL,
  `widget_content` longtext NOT NULL,
  `widget_revised` datetime NOT NULL,
  PRIMARY KEY (`widget_id`),
  UNIQUE KEY `widget_identifier` (`widget_identifier`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`widget_id`, `widget_name`, `widget_identifier`, `widget_title`, `widget_content`, `widget_revised`) VALUES
(1, 'Test Widget', 'test_widget', 'Widget Test', '<h1>TEST WIDGET HERE&nbsp;</h1>\r\n<p>{{config identifier=footer_text}}</p>', '2014-08-27 08:41:32'),
(3, 'siru_test___edit_name', 'siru_test_edit_iden', 'suru_titleedit_title', '<p>contenteditethis is test siu</p>', '2014-08-25 08:45:58'),
(5, 'alin', 'test_widget_2', 'sdf', '<p>dsfadsfasdfdsaf</p>', '2014-08-27 08:17:44'),
(6, 'Our Mission Our Vision', 'mission_vision', '', '<h1>Our Mission&nbsp;</h1>\r\n<p>Himalayan Corporation aspires to become the most prominient company in the pet industry while maintainin and building on our reputation for innovative, healthy, and high quality products. to ensure we uphold these standards in each new enterp[rise, we are driven by a set of core values:</p>\r\n<ul>\r\n<li>Provide exceptional customer service</li>\r\n<li>Treat employees with the utmost respect</li>\r\n<li>Produce and sell products of the highest quality</li>\r\n<li>Maximize savings, satisfaction and value for our customer</li>\r\n<li>Fuel growth through customer referrals, Innovation and reputation</li>\r\n<li>Actively impact the community through our presence and charitable contributions</li>\r\n</ul>\r\n<p>Himalayan Corporation embodies a collection of divers pet products with the highest aspirations.</p>\r\n<h1>Our Vision</h1>\r\n<p>is to be recognized and respected for producin the healthiest and highest quality pet food and products in teh world.</p>', '2014-09-05 08:46:39'),
(7, 'Announcement', 'announcement', '', '<p>Dear Dog Lovers:<br /><br />We are devastated to learn the losses of so many dogs from taking the treats from China in the recent years. Our heart, prayers and solidarity are with the families who lost their dogs, the families who have dogs as their pets, and families who have pets.<br /><br />Product of highest quality and confidence should be the most essential priority of any product manufacturer. We, at Himalayan, strive to bring such products in the market, and put all efforts to ensure that none of the ingredients and packaging materials is from China. We continue to procure our products from the USA and Nepal only, as we have in the past.<br /><br />Please contact <a href="mailto:info@himalayandogchew.com">info@himalayandogchew.com</a> if you have any questions, concerns or suggestions.<br /><br />Sujan Kumar Shrestha<br />Chairman &amp; CEO</p>', '0000-00-00 00:00:00'),
(8, 'Privacy Policy', 'privacy-policy', '', '<p><big><strong>Privacy Policy</strong></big> <br /><br />At HimalayanDogChew.com and Himalayan Corporation dba Himalayan Dog Chew, we are concerned with protecting your privacy. We use the information we collect about you to provide a discreet and professional experience. We may also use it to tell you about special offers and other news that we think you''d appreciate via our digital and/or paper newsletters. You''ll never have to worry about receiving a barrage of unexpected email from us besides information regarding your purchase orders, news regarding our products and offers, billing inquiries, and replies to any correspondence that you initiated. We will NOT provide, sell, rent or trade your information to/with anyone else, under any circumstance, except when warranted by the Courts of law and subpoenaed by the legislation of the United States of America and her States. <br /><br />We occasionally have third party agents, subsidiaries, affiliates and joint ventures that perform functions on our behalf. They have access to personal information needed to perform their functions, and are contractually obligated to maintain the confidentiality and security of the data. They are restricted from using this data for other purposes, and in any way other than to provide the requested services to us, and may not alter or resell the data. <br /><br />There is a possibility that we and our subsidiaries, joint ventures, affiliates, or any combination of such, could merge with, acquire, or be acquired by another business entity. If such an action occurs, we would like to let you know that some or all of the personal information collected about you would be shared with this entity in order to continue to provide reliable service. Notice of such an event will be posted on this page, and we will require that all parties follow the practices disclosed in this Privacy Policy unless otherwise noted. <br /><br />When registering with us, we will ask for some contact information, such as your name and email address. We will use the customer contact information from the registration form to send you information about our company. <br /><br />Sometimes you will provide us with data that doesn''t reveal your personal identity - what breed of dog do you pet, for example. We use this sort of information for editorial and personalization purposes, and occasionally for other internal purposes but we do not connect it to any name, address or other personal identifying information. <br /><br />If we know a visitor is under the age of thirteen, we will collect a parent''s permission offline (by postal mail, fax or phone) before we collect or share personal information with anyone else. <br /><br />Please note that nowhere on the website do we knowingly collect contact information or financial information from children under the age of 13. <br /><br /><strong>Email Notice</strong> <br /><br />Email, in general, is not a secure form of communication, and can be intercepted as it travels across the Internet. DO NOT send credit card numbers or other sensitive information via email. <br /><br />Revised May 1, 2012.</p>', '0000-00-00 00:00:00'),
(9, 'Web Usage Agreement', 'web-usage', '', '<p><big><strong>Terms and conditions of website usage</strong></big> <br /><br />Welcome to our website. If you continue to browse and use this website you are agreeing to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern Himalayan Corporation''s relationship with you in relation to this website. <br /><br />The term "Himalayan Dog Chew" or "Himalayan Corporation" or "us" or "we" refers to the owner of the website whose registered office is 4480 Chennault Beach Rd, Mukilteo, WA 98275. Our company registration number is 602-419-977 in the state of Washington, USA. The term "you" refers to the user or viewer of our website. <br /><br />The use of this website is subject to the following terms of use:</p>\r\n<ul type="circle">\r\n<li>The content of the pages of this website is for your general information and use only. It is subject to change without notice.</li>\r\n<li>Neither we nor any third parties provide any warranty or guarantee as to the accuracy, timeliness, performance, completeness or suitability of the information and materials found or offered on this website for any particular purpose. You acknowledge that such information and materials may contain inaccuracies or errors and we expressly exclude liability for any such inaccuracies or errors to the fullest extent permitted by law.</li>\r\n<li>Your use of any information or materials on this website is entirely at your own risk, for which we shall not be liable. It shall be your own responsibility to ensure that any products, services or information available through this website meet your specific requirements.</li>\r\n<li>This website contains material which is owned by or licensed to us. This material includes, but is not limited to, the design, layout, look, appearance and graphics. Reproduction is prohibited other than in accordance with the copyright notice, which forms part of these terms and conditions.</li>\r\n<li>All trademarks reproduced in this website, which are not the property of, or licensed to the operator, are acknowledged on the website.</li>\r\n<li>Unauthorised use of this website may give to a claim for damages and/or be a criminal offence.</li>\r\n<li>From time to time this website may also include links to other websites. These links are provided for your convenience to provide further information. They do not signify that we endorse the website(s). We have no responsibility for the content of the linked website(s).</li>\r\n<li>You may not create a link to this website from another website or document without Himalayan Corporation''s prior written consent.</li>\r\n<li>Your use of this website and any dispute arising out of such use of the website is subject to the laws of the State of Washington and the laws of the United States of America.</li>\r\n</ul>\r\n<p>Revised May 1, 2012.</p>', '0000-00-00 00:00:00');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `a_as`
--
ALTER TABLE `a_as`
  ADD CONSTRAINT `a_as_ibfk_1` FOREIGN KEY (`aas_aid`) REFERENCES `attributes` (`aid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `a_as_ibfk_2` FOREIGN KEY (`aas_asid`) REFERENCES `attributeset` (`asid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products_simple`
--
ALTER TABLE `products_simple`
  ADD CONSTRAINT `products_simple_ibfk_2` FOREIGN KEY (`product_asid`) REFERENCES `attributeset` (`asid`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `product_attribute_values_int`
--
ALTER TABLE `product_attribute_values_int`
  ADD CONSTRAINT `product_attribute_values_int_ibfk_1` FOREIGN KEY (`pavi_pid`) REFERENCES `products_simple` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_values_int_ibfk_2` FOREIGN KEY (`pavi_aid`) REFERENCES `attributes` (`aid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_attribute_values_select`
--
ALTER TABLE `product_attribute_values_select`
  ADD CONSTRAINT `product_attribute_values_select_ibfk_1` FOREIGN KEY (`pavs_pid`) REFERENCES `products_simple` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_values_select_ibfk_2` FOREIGN KEY (`pavs_aid`) REFERENCES `attributes` (`aid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_values_select_ibfk_3` FOREIGN KEY (`pavs_vid`) REFERENCES `attribute_values` (`vid`);

--
-- Constraints for table `product_attribute_values_text`
--
ALTER TABLE `product_attribute_values_text`
  ADD CONSTRAINT `product_attribute_values_text_ibfk_1` FOREIGN KEY (`pavt_pid`) REFERENCES `products_simple` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_values_text_ibfk_2` FOREIGN KEY (`pavt_aid`) REFERENCES `attributes` (`aid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_attribute_values_varchar`
--
ALTER TABLE `product_attribute_values_varchar`
  ADD CONSTRAINT `product_attribute_values_varchar_ibfk_1` FOREIGN KEY (`pavv_pid`) REFERENCES `products_simple` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_values_varchar_ibfk_2` FOREIGN KEY (`pavv_aid`) REFERENCES `attributes` (`aid`);
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
