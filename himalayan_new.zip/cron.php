<?php

echo 'cron';